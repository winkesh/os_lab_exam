#include "types.h"
#include "defs.h"
#include "param.h"
#include "spinlock.h"

#define N 8

struct
{
    struct spinlock lock;
    struct 
    {
        int val;
        int use;
    } s[N];
} semtable;

void seminit(void)
{
    initlock(&semtable.lock,"semtable");
}

int sem_init(int id,int val)
{
    if(id<0 || id>=N || val<0) return -1;
    acquire(&semtable.lock);
    semtable.s[id].val=val;
    semtable.s[id].use=1;
    release(&semtable.lock);
    return 0;
}

int sem_wait(int id)
{
    if(id<0 || id>=N) return -1;
    acquire(&semtable.lock);
    if(!semtable.s[id].use)
    {
        release(&semtable.lock);
        return -1;
    }
    while(semtable.s[id].val==0) sleep(&semtable.s[id],&semtable.lock);
    semtable.s[id].val--;
    release(&semtable.lock);
    return 0;
}

int sem_post(int id)
{
    if(id<0 || id>=N) return -1;
    acquire(&semtable.lock);
    if(!semtable.s[id].use)
    {
        release(&semtable.lock);
        return -1;
    }
    semtable.s[id].val++;
    wakeup(&semtable.s[id]);
    release(&semtable.lock);
    return 0;
}
