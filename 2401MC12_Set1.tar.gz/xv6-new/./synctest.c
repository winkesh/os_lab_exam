#include "types.h"
#include "stat.h"
#include "user.h"

int main(void)
{
    sem_init(0,1);
    sem_init(1,0);
    sem_init(2,0);
    
    for(int i=0;i<3;i++)
    {
        if(fork()==0)
        {
            for(int j=0;j<5;j++)
            {
                sem_wait(i);
                printf(1,"%c ",(char)(65+i));
                sem_post((i+1)%3);
            }
            exit();
        }
    }
    
    for(int i=0;i<3;i++) wait();
    printf(1,"\nDone\n");
    exit();
}
