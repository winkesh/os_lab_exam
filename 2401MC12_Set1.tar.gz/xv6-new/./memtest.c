#include "types.h"
#include "stat.h"
#include "user.h"

int g=313213;

int main(void)
{
    int n1,n2,n3,pid;
    
    printf(1,"1. freepages at start = %d\n",freepages());
    sbrk(10*4096);
    printf(1,"2. freepages after sbrk = %d\n",freepages());
    printf(1,"3. global addr: va = 0x%x and pa = 0x%x\n",(int)&g,va2pa((int)&g));
    printf(1,"4. va2pa(0x7FFFFFFF) = %d\n",va2pa(0x7FFFFFFF));
    
    n1=freepages();
    pid=fork();
    if(pid==0)
    {
        printf(1,"5. child addr: va = 0x%x and pa=0x%x\n",(int)&g,va2pa((int)&g));
        exit();
    }
    printf(1,"5. parent addr: va = 0x%x and pa=0x%x\n",(int)&g,va2pa((int)&g));
    n2=freepages();
    wait();
    n3=freepages();
    
    printf(1,"free pages before fork = %d\n",n1);
    printf(1,"free pages after fork = %d\n",n2);
    printf(1,"free pages after wait = %d\n",n3);
    if(n1==n3) printf(1,"NO LEAK\n");
    else printf(1,"LEAK\n");
    exit();
}
